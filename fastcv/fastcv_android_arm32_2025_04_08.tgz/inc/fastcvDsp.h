#ifndef FASTCV_DSP_H
#define FASTCV_DSP_H

/**=============================================================================

@file
   fastcvDsp.h

@brief
   This header file contains APIs optimized for Qualcomm's DSP.

Copyright (c) 2010, 2012-2025 Qualcomm Technologies, Inc.
All Rights Reserved.
Confidential and Proprietary - Qualcomm Technologies, Inc.

=============================================================================**/
/**=============================================================================
*
* The functions in this file are designed to leverage the capabilities of Qualcomm's DSP for enhanced performance.
* Each API in this file has a 'Q' appended to its name to distinguish it from the standard FastCV APIs found in fastcv.h.
* For example, the standard API 'fcvFFTu8' in fastcv.h corresponds to 'fcvFFTu8Q' in fastcvDsp.h.
*
* Before calling any 'fcv*Q' API, users must initialize the DSP by calling 'fcvQ6Init'.
*
* For more details about any API, please refer to the documentation in fastcv.h for a matching parameter set version of API.
* 
=============================================================================**/

//==============================================================================
// Include Files
//==============================================================================
#include "fastcv.h"

#ifdef __cplusplus
extern "C" {
#endif

//==============================================================================
// Declarations
//==============================================================================

//---------------------------------------------------------------------------
/// @brief
///   Initializes DSP for at run-time.
///   \n\b WARNING: Should be called once at the very beginning to initialize DSP mode
///
/// @param mode
///   See enum for details.
///
/// @return
///   0 if successful.
///   1 if unsuccessful.
///
/// @ingroup misc
//---------------------------------------------------------------------------
FASTCV_API int fcvQ6Init();

FASTCV_API void fcvQ6DeInit();

FASTCV_API void* fcvHwMemAlloc(uint32_t nBytes, uint32_t byteAlignment);

FASTCV_API void fcvHwMemFree(void* ptr);

FASTCV_API void
fcvSumOfAbsoluteDiffs8x8u8_v2Q(const uint8_t* __restrict patch,
                                    unsigned int              patchStride,
                                    const uint8_t* __restrict src,
                                    unsigned int              srcWidth,
                                    unsigned int              srcHeight,
                                    unsigned int              srcStride,
                                    uint16_t* __restrict      dst,
                                    unsigned int              dstStride);

FASTCV_API fcvStatus
fcvFFTu8Q(const uint8_t* __restrict src,
            uint32_t                  srcWidth,
            uint32_t                  srcHeight,
            uint32_t                  srcStride,
            float32_t* __restrict     dst,
            uint32_t                  dstStride);

FASTCV_API fcvStatus
fcvIFFTf32Q(const float32_t* __restrict src,
               uint32_t                     srcWidth,
               uint32_t                     srcHeight,
               uint32_t                     srcStride,
               uint8_t* __restrict          dst,
               uint32_t                     dstStride);

FASTCV_API void
fcvFilterThresholdOtsuu8Q(const uint8_t* __restrict src,
                           uint32_t                  srcWidth,
                           uint32_t                  srcHeight,
                           uint32_t                  srcStride,
                           uint8_t* __restrict       dst,
                           uint32_t                  dstStride,
                           fcvThreshType             thresholdType);

FASTCV_API fcvStatus
fcvFilterCannyu8Q(const uint8_t* __restrict src,
                     uint32_t                  srcWidth,
                     uint32_t                  srcHeight,
                     uint32_t                  srcStride,
                     uint8_t                   kernelSize,
                     int32_t                   lowThresh,
                     int32_t                   highThresh,
                     fcvNormType               normType,
                     uint8_t* __restrict       dst,
                     uint32_t                  dstStride,
                     int16_t* __restrict       gx,
                     int16_t* __restrict       gy,
                     uint32_t                  gradStride);

FASTCV_API void
fcvFilterCorr3x3s8_v2Q(const int8_t* __restrict kernel,
                        const uint8_t* __restrict src,
                        unsigned int              srcWidth,
                        unsigned int              srcHeight,
                        unsigned int              srcStride,
                        uint8_t* __restrict       dst,
                        unsigned int              dstStride);

FASTCV_API fcvStatus
fcvFilterCorrNxNu8Q(const int8_t* __restrict kernel,
                        uint32_t                  N,
                        int8_t                    shift,
                        const uint8_t* __restrict src,
                        uint32_t                  srcWidth,
                        uint32_t                  srcHeight,
                        uint32_t                  srcStride,
                        uint8_t* __restrict       dst,
                        uint32_t                  dstStride);

FASTCV_API fcvStatus
fcvFilterCorrNxNu8s16Q(const int8_t* __restrict kernel,
                        uint32_t                  N,
                        int8_t                    shift,
                        const uint8_t* __restrict src,
                        uint32_t                  srcWidth,
                        uint32_t                  srcHeight,
                        uint32_t                  srcStride,
                        int16_t* __restrict       dst,
                        uint32_t                  dstStride);

FASTCV_API fcvStatus
fcvFilterCorrNxNu8f32Q(const float32_t* __restrict kernel,
                        uint32_t                    N,
                        const uint8_t* __restrict   src,
                        uint32_t                    srcWidth,
                        uint32_t                    srcHeight,
                        uint32_t                    srcStride,
                        float32_t* __restrict       dst,
                        uint32_t                    dstStride);

#ifdef __cplusplus
}
#endif

#endif