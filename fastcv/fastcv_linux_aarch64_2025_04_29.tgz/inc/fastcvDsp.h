#ifndef FASTCV_DSP_H
#define FASTCV_DSP_H

/**=============================================================================

@file
   fastcvDsp.h

@brief
   This header file contains APIs optimized for Qualcomm's DSP.

Copyright (c) 2010, 2012-2025 Qualcomm Technologies, Inc.
All Rights Reserved.
Confidential and Proprietary - Qualcomm Technologies, Inc.

=============================================================================**/
/**=============================================================================
*
* The functions in this file are designed to leverage the capabilities of Qualcomm's DSP for enhanced performance.
* Each API in this file has a 'Q' appended to its name to distinguish it from the standard FastCV APIs found in fastcv.h.
* For example, the standard API 'fcvFFTu8' in fastcv.h corresponds to 'fcvFFTu8Q' in fastcvDsp.h.
*
* Before calling any 'fcv*Q' API, users must initialize the DSP by calling 'fcvQ6Init'.
*
* For more details about any API, please refer to the documentation in fastcv.h for a matching parameter set version of API.
*
=============================================================================**/

//==============================================================================
// Include Files
//==============================================================================
#include <stdbool.h>
#include "fastcv.h"

#ifdef __cplusplus
extern "C" {
#endif

//==============================================================================
// Declarations
//==============================================================================

//------------------------------------------------------------------------------
/// @brief
///   Initializes the DSP.
///
///   This function sets up the necessary environment and resources for the DSP to operate.
///   It must be called once at the very beginning of the program to ensure that the DSP is
///   properly initialized before any DSP-related operations are performed.
///
///   \b Important:
///   \n 1. This function must be called before any other FastCV DSP functions.
///   \n 2. Once FastCV DSP operations are completed and the DSP is no longer required,
///         'fcvQ6DeInit' must be called to clean up resources.
///
/// @return
///   0 if the initialization is successful.
///   1 if the initialization fails.
///
/// @ingroup misc
//------------------------------------------------------------------------------

FASTCV_API int fcvQ6Init();

//------------------------------------------------------------------------------
/// @brief
///   De-initializes the DSP that was initialized by the 'fcvQ6Init' function.
///
///   This function releases the resources and environment set up by the 'fcvQ6Init' function.
///   It should be called before the program exits to ensure that all DSP resources are properly
///   cleaned up and no memory leaks occur.
///
///   \b Important:
///   \n 1. This function must be called at the end of the program, after all DSP-related operations are complete.
///
/// @ingroup misc
//------------------------------------------------------------------------------

FASTCV_API void fcvQ6DeInit();

//------------------------------------------------------------------------------
/// @brief
///    Allocates aligned memory.
///
/// @param nBytes
///    Number of bytes.
///
/// @param byteAlignment
///    Alignment specified in bytes (e.g., 16 = 128-bit alignment).
///    \n\b WARNING: must be < 255 bytes
///
/// @return
///    SUCCESS: pointer to aligned memory
///    FAILURE: 0
///
/// @ingroup mem_management
//------------------------------------------------------------------------------

FASTCV_API void* fcvHwMemAlloc(uint32_t nBytes, uint32_t byteAlignment);

//------------------------------------------------------------------------------
/// @brief
///    Frees memory allocated by fcvHwMemAlloc().
///
/// @param ptr
///    Pointer to memory.
///
/// @ingroup mem_management
//------------------------------------------------------------------------------

FASTCV_API void fcvHwMemFree(void* ptr);

//------------------------------------------------------------------------------
/// @brief
///   Sum of absolute differences of an image against an 8x8 template.
///
/// @details
///   8x8 sum of ||A-B||. The template patch is swept over the entire image and
///   the results are put in dst.
///
/// @param patch
///   8x8 template
///
/// @param patchStride
///   Stride of the 8x8 template buffer
///
/// @param dstStride
///   Stride of the patch (in bytes) - i.e., how many bytes between column 0 of row N
///   and column 0 of row N+1.
///
/// @param src
///   Reference Image.
///   \n\b NOTE: should be 128-bit aligned.
///
/// @param srcWidth
///    Width of the src image.
///
/// @param srcHeight
///    Height of the src image.
///
/// @param srcStride
///   Stride of image (in bytes) - i.e., how many bytes between column 0 of row N
///   and column 0 of row N+1.
///
/// @param dst
///   The dst buffer shall be at least ( width x height ) values in length.
///   Output of SAD(A,B). dst[4][4]correspondes to the 0,0 pixel of the template
///   aligned with the 0,0 pixel of src. The dst border values not covered by
///   entire 8x8 patch window will remain unmodified by the function. The caller
///   should either initialize these to 0 or ignore.
///   \n\b NOTE: should be 128-bit aligned.
///
/// @param dstStride
///   Stride of destination (in bytes) - i.e., how many bytes between column 0 of row N
///   and column 0 of row N+1.
///
///
///
/// @ingroup object_detection
//------------------------------------------------------------------------------

FASTCV_API void
fcvSumOfAbsoluteDiffs8x8u8_v2Q(const uint8_t* __restrict patch,
                                    unsigned int              patchStride,
                                    const uint8_t* __restrict src,
                                    unsigned int              srcWidth,
                                    unsigned int              srcHeight,
                                    unsigned int              srcStride,
                                    uint16_t* __restrict      dst,
                                    unsigned int              dstStride);

//--------------------------------------------------------------------------------
///   Computes the 1D or 2D Fast Fourier Transform of a matrix.
///
/// @details
/// Computes the 1D or 2D Fast Fourier Transform of a real valued matrix.  For the
/// 2D case, The width and height of the input and output matrix must be powers of 2.
/// For the 1D case, the height of the matrices must be 1, while the width must be a power of 2.
///
/// @param src
///   An 8 bit unsigned real valued input matrix. The dimensions of the matrix must be powers
///   of 2 for the 2D case, and in the 1D case, the height must be 1, while the width must be
///   a power of 2.
///   \n\b NOTE: array should be 128-bit aligned
///
/// @param srcWidth
///   Width of the source matrix.
///   \n\b NOTE: Must be a power of 2
///
/// @param srcHeight
///   Height of the source matrix.
///   \n\b NOTE: Must be a power of 2 for the 2D case, and must be set to 1 for the 1D case
///
/// @param srcStride
///   Stride of the input matrix. Stride is the number of bytes between column 0 of row 1 and
///   column 0 of row 2 in data memory. If left at 0 srcStride is set to srcWidth.
///   \n\b WARNING: should be multiple of 8
///
/// @param dst
///   The computed FFT matrix. The FFT coefficients are stored in interleaved fashion, i.e.,
///   Re1 Im1 Re2 Im2 and so on. Hence the dimensions of the dst are (2 x srcWidth, srcHeight)
///   \n\b NOTE: array should be 128-bit aligned
///
/// @param dstStride
///   Stride of the output  matrix. Stride is the number of bytes between column 0 of row 1 and
///   column 0 of row 2 in data memory. If left at 0, dstStride is set to 2 x srcWidth x sizeof(float32_t).
///   \n\b WARNING: should be multiple of 8
///
/// @ingroup image_transform
//---------------------------------------------------------------------------

FASTCV_API fcvStatus
fcvFFTu8Q(const uint8_t* __restrict src,
            uint32_t                  srcWidth,
            uint32_t                  srcHeight,
            uint32_t                  srcStride,
            float32_t* __restrict     dst,
            uint32_t                  dstStride);

//---------------------------------------------------------------------------
/// @brief
///   Computes the 1D or 2D Inverse Fast Fourier Transform of a matrix.
///
/// @details
/// Computes the 1D or 2D Inverse Fast Fourier Transform of a complex valued matrix.  For the
/// 2D case, The width and height of the input and output matrix must be powers of 2.
/// For the 1D case, the height of the matrices must be 1, while the width must be a power of 2.
///
/// @param src
///   An 32 bit floating point complex valued input matrix. The data in the matrix must be stored
///   in an interleaved fashion, i.e., Re1 Im1 Re2 Im2 and so on. The dimensions of the matrix must
///   be powers of 2 for the 2D case, and in the 1D case, the height must be 1, while the width must be
///   a power of 2.
///   \n\b NOTE: array should be 128-bit aligned
///
/// @param srcWidth
///   Width of the source matrix. The width here is the number of floating point units in the matrix. Since
///   the data is interleaved fashion, i.e., Re1 Im1 Re2 Im2 and so on, the width is the total number of real
///   and complex units in the matrix. For example, if the Matrix has data values Re1 Im1 Re2 Im2 Re3 Im3 Re4 Im4,
///   then the width here is 8 units.
///   \n\b NOTE: Must be a power of 2
///
/// @param srcHeight
///   Height of the source matrix.
///   \n\b NOTE: Must be a power of 2 for the 2D case, and must be set to 1 for the 1D case
///
/// @param srcStride
///   Stride of the input matrix. Stride is the number of bytes between column 0 of row 1 and
///   column 0 of row 2 in data memory. If left at 0 srcStride is set to srcWidth x sizeof(float32_t).
///   \n\b WARNING: should be multiple of 8
///
/// @param dst
///   The computed IFFT matrix. The matrix is real valued and has no imaginary components.
///   Hence the dimensions of the dst are (srcWidth / 2 , srcHeight)
///   \n\b NOTE: array should be 128-bit aligned
///
/// @param dstStride
///   Stride of the output  matrix. Stride is the number of bytes between column 0 of row 1 and
///   column 0 of row 2 in data memory. If left at 0, dstStride is set to (srcWidth / 2).
///   \n\b WARNING: should be multiple of 8
///
/// @ingroup image_transform
//---------------------------------------------------------------------------

FASTCV_API fcvStatus
fcvIFFTf32Q(const float32_t* __restrict src,
               uint32_t                     srcWidth,
               uint32_t                     srcHeight,
               uint32_t                     srcStride,
               uint8_t* __restrict          dst,
               uint32_t                     dstStride);

//------------------------------------------------------------------------------
/// @brief
///   Binarizes a grayscale image using Otsu's method.
///
/// @details
///   Sets the pixel to max(255) if it's value is greater than the threshold;
///   else, set the pixel to min(0). The threshold is searched that minimizes
///   the intra-class variance (the variance within the class)
///
/// @param src
///   Input 8-bit image. Size of buffer is srcStride*srcHeight bytes.
///   \n\b WARNING: should be 128-bit aligned.
///
/// @param srcWidth
///   Image width.
///
/// @param srcHeight
///   Image height.
///
/// @param srcStride
///   Stride of image is the number of bytes between column 0 of row 1 and
///   column 0 of row 2 in data memory.
///   \n\b WARNING: should be multiple of 8
///
/// @param dst
///   Output 8-bit binarized image. Size of buffer is dstStride*srcHeight bytes.
///   If src equals to dst and srcStride equals to dstStride, it will do in-place.
///   \n\b WARNING: should be 128-bit aligned.
///
/// @param dstStride
///   Stride of image is the number of bytes between column 0 of row 1 and
///   column 0 of row 2 in data memory.
///   \n\b WARNING: should be multiple of 8
///
/// @param thresholdType
///   Threshold type that can be either FCV_THRESH_BINARY or FCV_THRESH_BINARY_INV.
///   \n\b NOTE: ///   For FCV_THRESH_BINARY threshold type, the pixel is set as
///   maxValue if it's value is greater than the threshold; else, it is set as zero.
///   For FCV_THRESH_BINARY_INV threshold type, the pixel is set as zero if it's
///   value is greater than the threshold; else, it is set as maxValue.
///
/// @ingroup image_processing
//------------------------------------------------------------------------------

FASTCV_API void
fcvFilterThresholdOtsuu8Q(const uint8_t* __restrict src,
                           uint32_t                  srcWidth,
                           uint32_t                  srcHeight,
                           uint32_t                  srcStride,
                           uint8_t* __restrict       dst,
                           uint32_t                  dstStride,
                           fcvThreshType             thresholdType);

//------------------------------------------------------------------------------
/// @brief
///   Canny edge detection with more controls to configurate the algorithm.
///
/// @details
///   Canny edge detector applied to a 8 bit grayscale image.
///   The results are stored as a binarized image (0x0 - not an edge, 0xFF - edge).
///
/// @param src
///   Input 8-bit image. Size of buffer is srcStride*srcHeight bytes.
///   \n\b WARNING: data should be 128-bit aligned.
///
/// @param srcWidth
///   Image width.
///   \n\b NOTE: should be multiple of 8
///
/// @param srcHeight
///   Image height.
///
/// @param srcStride
///   Stride of the input image in bytes.
///   \n\b NOTE: if 0, srcStride is set as srcWidth.
///   \n\b WARNING: should be multiple of 8, and at least as much as srcWidth if not 0.
///
/// @param kernelSize
///   The Sobel kernel size for calculating gradient. Supported sizes are 3, 5 and 7.
///
/// @param lowThresh
///   For all the intermediate pixels along the edge, the norm of the
///   gradient at the pixel locations should be greater than 'lowThresh'.
///
/// @param highThresh
///   For an edge starting point, i.e. either the first or last
///   pixel of the edge, the norm of the gradient at the pixel should be
///   greater than 'highThresh'.
///
/// @param normType
///   The norm definition to calculate the gradient magnitude. See fcvNormType.
///
/// @param dst
///   Output 8-bit binarized image containing the edge detection results.
///   Size of buffer is dstStride*srcHeight bytes.
///   Edges are marked with pixels of 0xFF. The rest pixels have values of 0.
///
/// @param dstStride
///   Stride of the output image in bytes.
///   \n\b NOTE: if 0, dstStride is set as srcWidth.
///   \n\b WARNING: should be multiple of 8, and at least as much as srcWidth if not 0.
///
///  @param gx
///   Buffer to store horizontal gradient. Must be (gradStride)*(srcHeight) bytes in size.
///   \n\b NOTE: should be 128-bit aligned.
///
/// @param gy
///   Buffer to store vertical gradient. Must be (gradStride)*(srcHeight) bytes in size.
///   \n\b NOTE: should be 128-bit aligned.
///
/// @param gradStride
///   Stride (in bytes) of 'gx' and 'gy' gradient arrays,
///   is the number of bytes between column 0 of row 1 and
///   column 0 of row 2 in the gradient arrays dx or dy.
///   If left at 0 gradStride is default to 2 * srcWidth.
///   \n\b NOTE: should be multiple of 8.
///
/// @ingroup image_processing
//------------------------------------------------------------------------------

FASTCV_API fcvStatus
fcvFilterCannyu8Q(const uint8_t* __restrict src,
                     uint32_t                  srcWidth,
                     uint32_t                  srcHeight,
                     uint32_t                  srcStride,
                     uint8_t                   kernelSize,
                     int32_t                   lowThresh,
                     int32_t                   highThresh,
                     fcvNormType               normType,
                     uint8_t* __restrict       dst,
                     uint32_t                  dstStride,
                     int16_t* __restrict       gx,
                     int16_t* __restrict       gy,
                     uint32_t                  gradStride);

//------------------------------------------------------------------------------
/// @brief
///   3x3 correlation with non-separable kernel.
///
/// @param kernel
///   2-D 3x3 kernel.
///   \n\b NOTE: Normalized to Q4.4
///
/// @param src
///   Input image. Size of buffer is srcStride*srcHeight bytes.
///   \n\b WARNING: should be 128-bit aligned.
///
/// @param srcWidth
///   Image width.
///   \n\b NOTE: must be an even number
///
/// @param srcHeight
///   Image height.
///   \n\b NOTE: must be an even number
///
/// @param srcStride
///   Image stride.
///   \n\b NOTE: if 0, srcStride is set as srcWidth.
///   \n\b WARNING: should be multiple of 8, and at least as much as srcWidth if not 0.
///
/// @param dst
///   Output convolution. Size of buffer is dstStride*srcHeight bytes.
///   \n\b NOTE: Must be same size as src
///   \n\b WARNING: should be 128-bit aligned.
///
/// @param dstStride
///   Output stride. Border values are ignored in this function.
///   \n\b NOTE: if 0, srcStride is set as srcWidth.
///   \n\b WARNING: should be multiple of 8, and at least as much as srcWidth if not 0.
///
///
///
/// @ingroup image_processing
//------------------------------------------------------------------------------

FASTCV_API void
fcvFilterCorr3x3s8_v2Q(const int8_t* __restrict kernel,
                        const uint8_t* __restrict src,
                        unsigned int              srcWidth,
                        unsigned int              srcHeight,
                        unsigned int              srcStride,
                        uint8_t* __restrict       dst,
                        unsigned int              dstStride);

//------------------------------------------------------------------------------
/// @brief
///   NxN correlation with non-separable kernel.
///   Border values are ignored in this function. The filling of dst starts
///   at (N/2,N/2) and ends at (srcWidth-1-N/2,srcHeight-1-N/2).
///   \n\b NOTE: The border is N/2 wide pixel strips at top, bottom, left and right of image.
///
/// @param kernel
///   2-D NxN kernel of int8_t.
///
/// @param N
///   Dimension of kernel.
///
/// @param shift
///   The right shift count used to normalize output.  Shift can be considered as Q factor of kernel.
///
/// @param src
///   Input image of unit8_t. Size of buffer is srcStride*srcHeight bytes.
///   \n\b WARNING: should be 128-bit aligned.
///
/// @param srcWidth
///   Image width.
///
/// @param srcHeight
///   Image height.
///
/// @param srcStride
///   Src image stride, stride of image is the number of bytes between column 0 of
///   row 1 and column 0 of row 2 in data memory.
///   \n\b NOTE: if 0, srcStride is set as srcWidth.
///   \n\b WARNING: should be multiple of 8, and at least as much as srcWidth if not 0.
///
/// @param dst
///   Output correlation. Size of buffer is dstStride*srcHeight bytes.
///   \n\b NOTE: Must be same size as src
///   \n\b WARNING: should be 128-bit aligned.
///
/// @param dstStride
///   Output stride, stride of image is the number of bytes between column 0 of
///   row 1 and column 0 of row 2 in data memory.
///   \n\b NOTE: if 0, dstStride is set as srcWidth.
///   \n\b WARNING: should be multiple of 8, and at least as much as
///                 srcWidth if not 0.
///
/// @return
///   FASTCV_SUCCESS upon success.
///   Other status codes upon failure.
///
/// @ingroup image_processing
//------------------------------------------------------------------------------

FASTCV_API fcvStatus
fcvFilterCorrNxNu8Q(const int8_t* __restrict kernel,
                        uint32_t                  N,
                        int8_t                    shift,
                        const uint8_t* __restrict src,
                        uint32_t                  srcWidth,
                        uint32_t                  srcHeight,
                        uint32_t                  srcStride,
                        uint8_t* __restrict       dst,
                        uint32_t                  dstStride);

//------------------------------------------------------------------------------
/// @brief
///   NxN correlation with non-separable kernel.
///   Border values are ignored in this function. The filling of dst starts
///   at (N/2,N/2) and ends at (srcWidth-1-N/2,srcHeight-1-N/2).
///   \n\b NOTE: The border is N/2 wide pixel strips at top, bottom, left and right of image.
///
/// @param kernel
///   2-D NxN kernel of int8_t.
///
/// @param N
///   Dimension of kernel.
///
/// @param shift
///   The right shift count used to normalize output. Shift can be considered as Q factor of kernel.
///
/// @param src
///   Input image of unit8_t. Size of buffer is srcStride*srcHeight bytes.
///   \n\b WARNING: should be 128-bit aligned.
///
/// @param srcWidth
///   Image width.
///
/// @param srcHeight
///   Image height.
///
/// @param srcStride
///   Src image stride, stride of image is the number of bytes between column 0 of
///   row 1 and column 0 of row 2 in data memory.
///   \n\b NOTE: if 0, srcStride is set as srcWidth.
///   \n\b WARNING: should be multiple of 8, and at least as much as srcWidth if not 0.
///
/// @param dst
///   Output correlation. Size of buffer is dstStride*srcHeight*sizeof(int16_t) bytes.
///   \n\b NOTE: Must be same size as src
///   \n\b WARNING: should be 128-bit aligned.
///
/// @param dstStride
///   Output stride, stride of image is the number of bytes between column 0 of
///   row 1 and column 0 of row 2 in data memory.
///   \n\b NOTE: if 0, dstStride is set as srcWidth*sizeof(int16_t).
///   \n\b WARNING: should be multiple of 8, and at least as much as
///                 srcWidth*sizeof(int16_t) if not 0.
///
/// @return
///   FASTCV_SUCCESS upon success.
///   Other status codes upon failure.
///
/// @ingroup image_processing
//------------------------------------------------------------------------------

FASTCV_API fcvStatus
fcvFilterCorrNxNu8s16Q(const int8_t* __restrict kernel,
                        uint32_t                  N,
                        int8_t                    shift,
                        const uint8_t* __restrict src,
                        uint32_t                  srcWidth,
                        uint32_t                  srcHeight,
                        uint32_t                  srcStride,
                        int16_t* __restrict       dst,
                        uint32_t                  dstStride);

//------------------------------------------------------------------------------
/// @brief
///   NxN correlation with non-separable kernel.
///   Border values are ignored in this function. The filling of dst starts
///   at (N/2,N/2) and ends at (srcWidth-1-N/2,srcHeight-1-N/2).
///   \n\b NOTE: The border is N/2 wide pixel strips at top, bottom, left and right of image.
///
/// @param kernel
///   2-D NxN kernel of float32_t.
///
/// @param N
///   Dimension of kernel.
///
/// @param src
///   Input image of unit8_t. Size of buffer is srcStride*srcHeight bytes.
///   \n\b WARNING: should be 128-bit aligned.
///
/// @param srcWidth
///   Image width.
///
/// @param srcHeight
///   Image height.
///
/// @param srcStride
///   Src image stride, stride of image is the number of bytes between column 0 of
///   row 1 and column 0 of row 2 in data memory.
///   \n\b NOTE: if 0, srcStride is set as srcWidth.
///   \n\b WARNING: should be multiple of 8, and at least as much as srcWidth if not 0.
///
/// @param dst
///   Output correlation. Size of buffer is dstStride*srcHeight*sizeof(float32_t) bytes.
///   \n\b NOTE: Must be same size as src
///   \n\b WARNING: should be 128-bit aligned.
///
/// @param dstStride
///   Output stride, stride of image is the number of bytes between column 0 of
///   row 1 and column 0 of row 2 in data memory.
///   \n\b NOTE: if 0, dstStride is set as srcWidth*sizeof(float32_t).
///   \n\b WARNING: should be multiple of 8, and at least as much as
///                 srcWidth*sizeof(float32_t) if not 0.
///
/// @return
///   FASTCV_SUCCESS upon success.
///   Other status codes upon failure.
///
/// @ingroup image_processing
//------------------------------------------------------------------------------

FASTCV_API fcvStatus
fcvFilterCorrNxNu8f32Q(const float32_t* __restrict kernel,
                        uint32_t                    N,
                        const uint8_t* __restrict   src,
                        uint32_t                    srcWidth,
                        uint32_t                    srcHeight,
                        uint32_t                    srcStride,
                        float32_t* __restrict       dst,
                        uint32_t                    dstStride);

#ifdef __cplusplus
}
#endif

#endif